################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/simplelink/cc_pal.c \
/src/simplelink/source/device.c \
/src/simplelink/source/driver.c \
/src/simplelink/source/flowcont.c \
/src/simplelink/source/fs.c \
/src/simplelink/source/netapp.c \
/src/simplelink/source/netcfg.c \
/src/simplelink/source/nonos.c \
/src/simplelink/source/socket.c \
/src/simplelink/source/spawn.c \
/src/simplelink/source/wlan.c 

OBJS += \
./cc_pal.obj \
./device.obj \
./driver.obj \
./flowcont.obj \
./fs.obj \
./netapp.obj \
./netcfg.obj \
./nonos.obj \
./socket.obj \
./spawn.obj \
./wlan.obj \
./netutil.obj 

C_DEPS += \
./cc_pal.pp \
./device.pp \
./driver.pp \
./flowcont.pp \
./fs.pp \
./netapp.pp \
./netcfg.pp \
./nonos.pp \
./socket.pp \
./spawn.pp \
./wlan.pp \
./netutil.pp 

C_DEPS__QUOTED += \
"cc_pal.pp" \
"device.pp" \
"driver.pp" \
"flowcont.pp" \
"fs.pp" \
"netapp.pp" \
"netcfg.pp" \
"nonos.pp" \
"socket.pp" \
"spawn.pp" \
"wlan.pp" 

OBJS__QUOTED += \
"cc_pal.obj" \
"device.obj" \
"driver.obj" \
"flowcont.obj" \
"fs.obj" \
"netapp.obj" \
"netcfg.obj" \
"nonos.obj" \
"socket.obj" \
"spawn.obj" \
"wlan.obj" 

C_SRCS__QUOTED += \
"/src/simplelink/cc_pal.c" \
"/src/simplelink/source/device.c" \
"/src/simplelink/source/driver.c" \
"/src/simplelink/source/flowcont.c" \
"/src/simplelink/source/fs.c" \
"/src/simplelink/source/netapp.c" \
"/src/simplelink/source/netcfg.c" \
"/src/simplelink/source/nonos.c" \
"/src/simplelink/source/socket.c" \
"/src/simplelink/source/spawn.c" \
"/src/simplelink/source/wlan.c" 


