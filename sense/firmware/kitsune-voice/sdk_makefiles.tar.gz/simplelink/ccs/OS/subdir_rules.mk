################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
cc_pal.obj: /src/simplelink/cc_pal.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="cc_pal.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

device.obj: /src/simplelink/source/device.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="device.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

driver.obj: /src/simplelink/source/driver.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="driver.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

flowcont.obj: /src/simplelink/source/flowcont.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="flowcont.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

fs.obj: /src/simplelink/source/fs.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="fs.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

netapp.obj: /src/simplelink/source/netapp.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="netapp.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

netcfg.obj: /src/simplelink/source/netcfg.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="netcfg.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

nonos.obj: /src/simplelink/source/nonos.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="nonos.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

socket.obj: /src/simplelink/source/socket.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="socket.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

spawn.obj: /src/simplelink/source/spawn.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="spawn.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

wlan.obj: /src/simplelink/source/wlan.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="wlan.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '



netutil.obj: /src/simplelink/source/netutil.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi -me --opt_level=off --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/simplelink/" --include_path="/src/simplelink/include" --include_path="/src/simplelink/source" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src/oslib/" -g --no_inlining --gcc --define=ccs --define=TARGET_IS_CC3200 --define=SL_FULL --define=SL_PLATFORM_MULTI_THREADED --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="netutil.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '
