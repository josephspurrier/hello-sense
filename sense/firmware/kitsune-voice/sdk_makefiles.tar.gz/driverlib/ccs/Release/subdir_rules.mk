################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
adc.obj: /src/driverlib/adc.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="adc.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

aes.obj: /src/driverlib/aes.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="aes.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

camera.obj: /src/driverlib/camera.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="camera.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

cpu.obj: /src/driverlib/cpu.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="cpu.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

crc.obj: /src/driverlib/crc.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="crc.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

des.obj: /src/driverlib/des.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="des.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

flash.obj: /src/driverlib/flash.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="flash.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

gpio.obj: /src/driverlib/gpio.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="gpio.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

hwspinlock.obj: /src/driverlib/hwspinlock.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="hwspinlock.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

i2c.obj: /src/driverlib/i2c.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="i2c.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

i2s.obj: /src/driverlib/i2s.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="i2s.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

interrupt.obj: /src/driverlib/interrupt.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="interrupt.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

pin.obj: /src/driverlib/pin.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="pin.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

prcm.obj: /src/driverlib/prcm.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="prcm.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

sdhost.obj: /src/driverlib/sdhost.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="sdhost.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

shamd5.obj: /src/driverlib/shamd5.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="shamd5.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

spi.obj: /src/driverlib/spi.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="spi.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

systick.obj: /src/driverlib/systick.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="systick.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

timer.obj: /src/driverlib/timer.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="timer.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

uart.obj: /src/driverlib/uart.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="uart.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

udma.obj: /src/driverlib/udma.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="udma.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

utils.obj: /src/driverlib/utils.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="utils.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

wdt.obj: /src/driverlib/wdt.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=vfplib --abi=eabi --opt_for_cache -me -O1 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/driverlib" --include_path="/src/inc" --include_path="/src" -g --gcc --define=ccs --define=DRIVERLIB_APPS --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="wdt.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '


