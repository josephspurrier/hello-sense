################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/portasm.asm 

C_SRCS += \
/src/third_party/FreeRTOS/source/SEGGER_RTT.c \
/src/third_party/FreeRTOS/source/SEGGER_SYSVIEW.c \
/src/third_party/FreeRTOS/source/SEGGER_SYSVIEW_Config_FreeRTOS.c \
/src/third_party/FreeRTOS/source/SEGGER_SYSVIEW_FreeRTOS.c \
/src/third_party/FreeRTOS/source/croutine.c \
/src/third_party/FreeRTOS/source/event_groups.c \
/src/third_party/FreeRTOS/source/portable/MemMang/heap_6.c \
/src/third_party/FreeRTOS/source/list.c \
/src/oslib/osi_freertos.c \
/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/port.c \
/src/third_party/FreeRTOS/source/queue.c \
/src/third_party/FreeRTOS/source/tasks.c \
/src/third_party/FreeRTOS/source/timers.c 

OBJS += \
./SEGGER_RTT.obj \
./SEGGER_SYSVIEW.obj \
./SEGGER_SYSVIEW_Config_FreeRTOS.obj \
./SEGGER_SYSVIEW_FreeRTOS.obj \
./croutine.obj \
./event_groups.obj \
./heap_6.obj \
./list.obj \
./osi_freertos.obj \
./port.obj \
./portasm.obj \
./queue.obj \
./tasks.obj \
./timers.obj 

ASM_DEPS += \
./portasm.pp 

C_DEPS += \
./SEGGER_RTT.pp \
./SEGGER_SYSVIEW.pp \
./SEGGER_SYSVIEW_Config_FreeRTOS.pp \
./SEGGER_SYSVIEW_FreeRTOS.pp \
./croutine.pp \
./event_groups.pp \
./heap_6.pp \
./list.pp \
./osi_freertos.pp \
./port.pp \
./queue.pp \
./tasks.pp \
./timers.pp 

C_DEPS__QUOTED += \
"SEGGER_RTT.pp" \
"SEGGER_SYSVIEW.pp" \
"SEGGER_SYSVIEW_Config_FreeRTOS.pp" \
"SEGGER_SYSVIEW_FreeRTOS.pp" \
"croutine.pp" \
"event_groups.pp" \
"heap_6.pp" \
"list.pp" \
"osi_freertos.pp" \
"port.pp" \
"queue.pp" \
"tasks.pp" \
"timers.pp" 

OBJS__QUOTED += \
"SEGGER_RTT.obj" \
"SEGGER_SYSVIEW.obj" \
"SEGGER_SYSVIEW_Config_FreeRTOS.obj" \
"SEGGER_SYSVIEW_FreeRTOS.obj" \
"croutine.obj" \
"event_groups.obj" \
"heap_6.obj" \
"list.obj" \
"osi_freertos.obj" \
"port.obj" \
"portasm.obj" \
"queue.obj" \
"tasks.obj" \
"timers.obj" 

ASM_DEPS__QUOTED += \
"portasm.pp" 

C_SRCS__QUOTED += \
"/src/third_party/FreeRTOS/source/SEGGER_RTT.c" \
"/src/third_party/FreeRTOS/source/SEGGER_SYSVIEW.c" \
"/src/third_party/FreeRTOS/source/SEGGER_SYSVIEW_Config_FreeRTOS.c" \
"/src/third_party/FreeRTOS/source/SEGGER_SYSVIEW_FreeRTOS.c" \
"/src/third_party/FreeRTOS/source/croutine.c" \
"/src/third_party/FreeRTOS/source/event_groups.c" \
"/src/third_party/FreeRTOS/source/portable/MemMang/heap_6.c" \
"/src/third_party/FreeRTOS/source/list.c" \
"/src/oslib/osi_freertos.c" \
"/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/port.c" \
"/src/third_party/FreeRTOS/source/queue.c" \
"/src/third_party/FreeRTOS/source/tasks.c" \
"/src/third_party/FreeRTOS/source/timers.c" 

ASM_SRCS__QUOTED += \
"/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/portasm.asm" 


