################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
SEGGER_RTT.obj: /src/third_party/FreeRTOS/source/SEGGER_RTT.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="SEGGER_RTT.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

SEGGER_SYSVIEW.obj: /src/third_party/FreeRTOS/source/SEGGER_SYSVIEW.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="SEGGER_SYSVIEW.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

SEGGER_SYSVIEW_Config_FreeRTOS.obj: /src/third_party/FreeRTOS/source/SEGGER_SYSVIEW_Config_FreeRTOS.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="SEGGER_SYSVIEW_Config_FreeRTOS.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

SEGGER_SYSVIEW_FreeRTOS.obj: /src/third_party/FreeRTOS/source/SEGGER_SYSVIEW_FreeRTOS.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="SEGGER_SYSVIEW_FreeRTOS.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

croutine.obj: /src/third_party/FreeRTOS/source/croutine.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="croutine.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

event_groups.obj: /src/third_party/FreeRTOS/source/event_groups.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="event_groups.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

heap_6.obj: /src/third_party/FreeRTOS/source/portable/MemMang/heap_6.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="heap_6.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

list.obj: /src/third_party/FreeRTOS/source/list.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="list.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

osi_freertos.obj: /src/oslib/osi_freertos.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="osi_freertos.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

port.obj: /src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/port.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="port.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

portasm.obj: /src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/portasm.asm $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="portasm.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

queue.obj: /src/third_party/FreeRTOS/source/queue.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="queue.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

tasks.obj: /src/third_party/FreeRTOS/source/tasks.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="tasks.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

timers.obj: /src/third_party/FreeRTOS/source/timers.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=relaxed --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/oslib" --include_path="/src/inc" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" -g --no_inlining --gcc --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --printf_support=full --ual --preproc_with_compile --preproc_dependency="timers.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '


