################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/driverlib/adc.c \
/src/driverlib/aes.c \
/src/driverlib/camera.c \
/src/driverlib/cpu.c \
/src/driverlib/crc.c \
/src/driverlib/des.c \
/src/driverlib/flash.c \
/src/driverlib/gpio.c \
/src/driverlib/hwspinlock.c \
/src/driverlib/i2c.c \
/src/driverlib/i2s.c \
/src/driverlib/interrupt.c \
/src/driverlib/pin.c \
/src/driverlib/prcm.c \
/src/driverlib/sdhost.c \
/src/driverlib/shamd5.c \
/src/driverlib/spi.c \
/src/driverlib/systick.c \
/src/driverlib/timer.c \
/src/driverlib/uart.c \
/src/driverlib/udma.c \
/src/driverlib/utils.c \
/src/driverlib/wdt.c 

OBJS += \
./adc.obj \
./aes.obj \
./camera.obj \
./cpu.obj \
./crc.obj \
./des.obj \
./flash.obj \
./gpio.obj \
./hwspinlock.obj \
./i2c.obj \
./i2s.obj \
./interrupt.obj \
./pin.obj \
./prcm.obj \
./sdhost.obj \
./shamd5.obj \
./spi.obj \
./systick.obj \
./timer.obj \
./uart.obj \
./udma.obj \
./utils.obj \
./wdt.obj 

C_DEPS += \
./adc.pp \
./aes.pp \
./camera.pp \
./cpu.pp \
./crc.pp \
./des.pp \
./flash.pp \
./gpio.pp \
./hwspinlock.pp \
./i2c.pp \
./i2s.pp \
./interrupt.pp \
./pin.pp \
./prcm.pp \
./sdhost.pp \
./shamd5.pp \
./spi.pp \
./systick.pp \
./timer.pp \
./uart.pp \
./udma.pp \
./utils.pp \
./wdt.pp 

C_DEPS__QUOTED += \
"adc.pp" \
"aes.pp" \
"camera.pp" \
"cpu.pp" \
"crc.pp" \
"des.pp" \
"flash.pp" \
"gpio.pp" \
"hwspinlock.pp" \
"i2c.pp" \
"i2s.pp" \
"interrupt.pp" \
"pin.pp" \
"prcm.pp" \
"sdhost.pp" \
"shamd5.pp" \
"spi.pp" \
"systick.pp" \
"timer.pp" \
"uart.pp" \
"udma.pp" \
"utils.pp" \
"wdt.pp" 

OBJS__QUOTED += \
"adc.obj" \
"aes.obj" \
"camera.obj" \
"cpu.obj" \
"crc.obj" \
"des.obj" \
"flash.obj" \
"gpio.obj" \
"hwspinlock.obj" \
"i2c.obj" \
"i2s.obj" \
"interrupt.obj" \
"pin.obj" \
"prcm.obj" \
"sdhost.obj" \
"shamd5.obj" \
"spi.obj" \
"systick.obj" \
"timer.obj" \
"uart.obj" \
"udma.obj" \
"utils.obj" \
"wdt.obj" 

C_SRCS__QUOTED += \
"/src/driverlib/adc.c" \
"/src/driverlib/aes.c" \
"/src/driverlib/camera.c" \
"/src/driverlib/cpu.c" \
"/src/driverlib/crc.c" \
"/src/driverlib/des.c" \
"/src/driverlib/flash.c" \
"/src/driverlib/gpio.c" \
"/src/driverlib/hwspinlock.c" \
"/src/driverlib/i2c.c" \
"/src/driverlib/i2s.c" \
"/src/driverlib/interrupt.c" \
"/src/driverlib/pin.c" \
"/src/driverlib/prcm.c" \
"/src/driverlib/sdhost.c" \
"/src/driverlib/shamd5.c" \
"/src/driverlib/spi.c" \
"/src/driverlib/systick.c" \
"/src/driverlib/timer.c" \
"/src/driverlib/uart.c" \
"/src/driverlib/udma.c" \
"/src/driverlib/utils.c" \
"/src/driverlib/wdt.c" 


