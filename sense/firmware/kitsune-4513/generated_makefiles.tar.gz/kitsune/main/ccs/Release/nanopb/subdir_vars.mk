################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/kitsune/nanopb/pb_common.c \
/src/kitsune/nanopb/pb_decode.c \
/src/kitsune/nanopb/pb_encode.c 

OBJS += \
./nanopb/pb_common.obj \
./nanopb/pb_decode.obj \
./nanopb/pb_encode.obj 

C_DEPS += \
./nanopb/pb_common.pp \
./nanopb/pb_decode.pp \
./nanopb/pb_encode.pp 

C_DEPS__QUOTED += \
"nanopb/pb_common.pp" \
"nanopb/pb_decode.pp" \
"nanopb/pb_encode.pp" 

OBJS__QUOTED += \
"nanopb/pb_common.obj" \
"nanopb/pb_decode.obj" \
"nanopb/pb_encode.obj" 

C_SRCS__QUOTED += \
"/src/kitsune/nanopb/pb_common.c" \
"/src/kitsune/nanopb/pb_decode.c" \
"/src/kitsune/nanopb/pb_encode.c" 


