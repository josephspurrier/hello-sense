################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
common/button_if.obj: /src/kitsune/common/button_if.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/button_if.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

common/gpio_if.obj: /src/kitsune/common/gpio_if.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/gpio_if.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

common/i2c_if.obj: /src/kitsune/common/i2c_if.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/i2c_if.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

common/startup_ccs.obj: /src/kitsune/common/startup_ccs.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/startup_ccs.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

common/timer_if.obj: /src/kitsune/common/timer_if.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/timer_if.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

common/udma_if.obj: /src/kitsune/common/udma_if.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/udma_if.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '

common/wdt_if.obj: /src/kitsune/common/wdt_if.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --code_state=16 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --fp_mode=strict --include_path="/src/third_party/fatfs/src" --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/driverlib/" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3/" --include_path="/src/third_party/FreeRTOS/source/include/" --include_path="/src/third_party/FreeRTOS/source/" --include_path="/src/oslib/" --include_path="/src/simplelink/" --include_path="/src/simplelink/source/" --include_path="/src/simplelink/include/" --include_path="/src/inc/" --include_path="/src/kitsune/common" --include_path="/src/kitsune/tests" --include_path="/src/kitsune/debugutils" --include_path="/src/kitsune/" --include_path="/src/kitsune/hashtable" --include_path="/src/kitsune/nanopb" --include_path="/src/kitsune/protobuf" --include_path="/src/kitsune/main/" -g --no_inlining --gcc --define=ccs --define=ARM --define=TARGET_IS_CC3200 --define=USE_FREERTOS --define=TI_CODEC --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="common/wdt_if.pp" --obj_directory="common" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '


