################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/kitsune/tinyhttp/chunk.c \
/src/kitsune/tinyhttp/header.c \
/src/kitsune/tinyhttp/http.c 

OBJS += \
./tinyhttp/chunk.obj \
./tinyhttp/header.obj \
./tinyhttp/http.obj 

C_DEPS += \
./tinyhttp/chunk.pp \
./tinyhttp/header.pp \
./tinyhttp/http.pp 

C_DEPS__QUOTED += \
"tinyhttp/chunk.pp" \
"tinyhttp/header.pp" \
"tinyhttp/http.pp" 

OBJS__QUOTED += \
"tinyhttp/chunk.obj" \
"tinyhttp/header.obj" \
"tinyhttp/http.obj" 

C_SRCS__QUOTED += \
"/src/kitsune/tinyhttp/chunk.c" \
"/src/kitsune/tinyhttp/header.c" \
"/src/kitsune/tinyhttp/http.c" 


