################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/kitsune/debugutils/matmessageutils.c 

OBJS += \
./debugutils/matmessageutils.obj 

C_DEPS += \
./debugutils/matmessageutils.pp 

C_DEPS__QUOTED += \
"debugutils/matmessageutils.pp" 

OBJS__QUOTED += \
"debugutils/matmessageutils.obj" 

C_SRCS__QUOTED += \
"/src/kitsune/debugutils/matmessageutils.c" 


