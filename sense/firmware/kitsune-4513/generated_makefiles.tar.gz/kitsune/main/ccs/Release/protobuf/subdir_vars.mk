################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/kitsune/protobuf/audio_commands.pb.c \
/src/kitsune/protobuf/audio_control.pb.c \
/src/kitsune/protobuf/audio_data.pb.c \
/src/kitsune/protobuf/file_manifest.pb.c \
/src/kitsune/protobuf/filetransfer.pb.c \
/src/kitsune/protobuf/log.pb.c \
/src/kitsune/protobuf/matrix.pb.c \
/src/kitsune/protobuf/messeji.pb.c \
/src/kitsune/protobuf/morpheus_ble.pb.c \
/src/kitsune/protobuf/ntp.pb.c \
/src/kitsune/protobuf/periodic.pb.c \
/src/kitsune/protobuf/provision.pb.c \
/src/kitsune/protobuf/state.pb.c \
/src/kitsune/protobuf/sync_response.pb.c 

OBJS += \
./protobuf/audio_commands.pb.obj \
./protobuf/audio_control.pb.obj \
./protobuf/audio_data.pb.obj \
./protobuf/file_manifest.pb.obj \
./protobuf/filetransfer.pb.obj \
./protobuf/log.pb.obj \
./protobuf/matrix.pb.obj \
./protobuf/messeji.pb.obj \
./protobuf/morpheus_ble.pb.obj \
./protobuf/ntp.pb.obj \
./protobuf/periodic.pb.obj \
./protobuf/provision.pb.obj \
./protobuf/state.pb.obj \
./protobuf/sync_response.pb.obj 

C_DEPS += \
./protobuf/audio_commands.pb.pp \
./protobuf/audio_control.pb.pp \
./protobuf/audio_data.pb.pp \
./protobuf/file_manifest.pb.pp \
./protobuf/filetransfer.pb.pp \
./protobuf/log.pb.pp \
./protobuf/matrix.pb.pp \
./protobuf/messeji.pb.pp \
./protobuf/morpheus_ble.pb.pp \
./protobuf/ntp.pb.pp \
./protobuf/periodic.pb.pp \
./protobuf/provision.pb.pp \
./protobuf/state.pb.pp \
./protobuf/sync_response.pb.pp 

C_DEPS__QUOTED += \
"protobuf/audio_commands.pb.pp" \
"protobuf/audio_control.pb.pp" \
"protobuf/audio_data.pb.pp" \
"protobuf/file_manifest.pb.pp" \
"protobuf/filetransfer.pb.pp" \
"protobuf/log.pb.pp" \
"protobuf/matrix.pb.pp" \
"protobuf/messeji.pb.pp" \
"protobuf/morpheus_ble.pb.pp" \
"protobuf/ntp.pb.pp" \
"protobuf/periodic.pb.pp" \
"protobuf/provision.pb.pp" \
"protobuf/state.pb.pp" \
"protobuf/sync_response.pb.pp" 

OBJS__QUOTED += \
"protobuf/audio_commands.pb.obj" \
"protobuf/audio_control.pb.obj" \
"protobuf/audio_data.pb.obj" \
"protobuf/file_manifest.pb.obj" \
"protobuf/filetransfer.pb.obj" \
"protobuf/log.pb.obj" \
"protobuf/matrix.pb.obj" \
"protobuf/messeji.pb.obj" \
"protobuf/morpheus_ble.pb.obj" \
"protobuf/ntp.pb.obj" \
"protobuf/periodic.pb.obj" \
"protobuf/provision.pb.obj" \
"protobuf/state.pb.obj" \
"protobuf/sync_response.pb.obj" 

C_SRCS__QUOTED += \
"/src/kitsune/protobuf/audio_commands.pb.c" \
"/src/kitsune/protobuf/audio_control.pb.c" \
"/src/kitsune/protobuf/audio_data.pb.c" \
"/src/kitsune/protobuf/file_manifest.pb.c" \
"/src/kitsune/protobuf/filetransfer.pb.c" \
"/src/kitsune/protobuf/log.pb.c" \
"/src/kitsune/protobuf/matrix.pb.c" \
"/src/kitsune/protobuf/messeji.pb.c" \
"/src/kitsune/protobuf/morpheus_ble.pb.c" \
"/src/kitsune/protobuf/ntp.pb.c" \
"/src/kitsune/protobuf/periodic.pb.c" \
"/src/kitsune/protobuf/provision.pb.c" \
"/src/kitsune/protobuf/state.pb.c" \
"/src/kitsune/protobuf/sync_response.pb.c" 


