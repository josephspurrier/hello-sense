################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -l"/src/kitsune/main/ccs/../../../third_party/fatfs/ccs/Release/fatfs.a" -l"/src/kitsune/main/ccs/../../../oslib/ccs/exe/FreeRTOS.a" -l"/src/kitsune/main/ccs/../../../simplelink/ccs/exe/simplelink.a" -l"/src/kitsune/main/ccs/../../../driverlib/ccs/Release/driverlib.a"

