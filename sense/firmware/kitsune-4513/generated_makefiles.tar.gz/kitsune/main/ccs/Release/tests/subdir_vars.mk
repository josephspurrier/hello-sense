################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/kitsune/tests/TestNetwork.c 

OBJS += \
./tests/TestNetwork.obj 

C_DEPS += \
./tests/TestNetwork.pp 

C_DEPS__QUOTED += \
"tests/TestNetwork.pp" 

OBJS__QUOTED += \
"tests/TestNetwork.obj" 

C_SRCS__QUOTED += \
"/src/kitsune/tests/TestNetwork.c" 


