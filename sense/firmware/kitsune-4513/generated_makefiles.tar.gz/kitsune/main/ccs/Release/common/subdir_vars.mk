################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
/src/kitsune/common/button_if.c \
/src/kitsune/common/gpio_if.c \
/src/kitsune/common/i2c_if.c \
/src/kitsune/common/startup_ccs.c \
/src/kitsune/common/timer_if.c \
/src/kitsune/common/udma_if.c \
/src/kitsune/common/wdt_if.c 

OBJS += \
./common/button_if.obj \
./common/gpio_if.obj \
./common/i2c_if.obj \
./common/startup_ccs.obj \
./common/timer_if.obj \
./common/udma_if.obj \
./common/wdt_if.obj 

C_DEPS += \
./common/button_if.pp \
./common/gpio_if.pp \
./common/i2c_if.pp \
./common/startup_ccs.pp \
./common/timer_if.pp \
./common/udma_if.pp \
./common/wdt_if.pp 

C_DEPS__QUOTED += \
"common/button_if.pp" \
"common/gpio_if.pp" \
"common/i2c_if.pp" \
"common/startup_ccs.pp" \
"common/timer_if.pp" \
"common/udma_if.pp" \
"common/wdt_if.pp" 

OBJS__QUOTED += \
"common/button_if.obj" \
"common/gpio_if.obj" \
"common/i2c_if.obj" \
"common/startup_ccs.obj" \
"common/timer_if.obj" \
"common/udma_if.obj" \
"common/wdt_if.obj" 

C_SRCS__QUOTED += \
"/src/kitsune/common/button_if.c" \
"/src/kitsune/common/gpio_if.c" \
"/src/kitsune/common/i2c_if.c" \
"/src/kitsune/common/startup_ccs.c" \
"/src/kitsune/common/timer_if.c" \
"/src/kitsune/common/udma_if.c" \
"/src/kitsune/common/wdt_if.c" 


