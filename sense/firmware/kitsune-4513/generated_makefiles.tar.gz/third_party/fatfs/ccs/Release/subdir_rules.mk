################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
ff.obj: /src/third_party/fatfs/src/ff.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: ARM Compiler'
	"/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/bin/armcl" -mv7M4 --float_support=FPv4SPD16 --abi=eabi -me -O4 --opt_for_speed=0 --include_path="/root/ti/ccsv6/tools/compiler/ti-cgt-arm_5.1.5/include" --include_path="/src/third_party/FreeRTOS/source/portable/CCS/ARM_CM3" --include_path="/src/driverlib" --include_path="/src/third_party/FreeRTOS/source/include" --include_path="/src/third_party/FreeRTOS/source" --include_path="/src/inc" --include_path="/src/third_party/fatfs/src/" -g --define=TARGET_IS_CC3200 --display_error_number --diag_warning=225 --diag_wrap=off --gen_func_subsections=on --unaligned_access=off -mt --preproc_with_compile --preproc_dependency="ff.pp" $(GEN_OPTS__FLAG) "$(shell echo $<)"
	@echo 'Finished building: $<'
	@echo ' '


